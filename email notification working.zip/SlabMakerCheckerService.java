package com.portfolio.service;

import com.portfolio.dto.SlabChangeRequestDTO;
import com.portfolio.exception.OneZappException;

public interface SlabMakerCheckerService {
    String processSlabMakerCheckerRequest(SlabChangeRequestDTO requestDTO,
                                          Integer officeUserId) throws OneZappException;

}