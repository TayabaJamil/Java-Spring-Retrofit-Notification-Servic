package com.portfolio.api;

import com.epsystems.dto.ApiResponse;
import com.epsystems.dto.MakerCheckerEmailDTO;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

import java.util.List;

public interface AlertServiceApi {
        @POST("/email/send-maker-checker-email")
        Call<ApiResponse> sendMakerCheckerEmail(@Body List<MakerCheckerEmailDTO> emailDTOList);
    }
